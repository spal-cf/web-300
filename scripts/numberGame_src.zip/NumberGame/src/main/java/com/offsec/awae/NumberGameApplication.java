package com.offsec.awae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumberGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumberGameApplication.class, args);
	}

}
